#include <stdio.h>
#include <stdlib.h>

int gerarQuantidadeDeChavesAleatoria();
int * gerarConjuntoPiorCaso(int n);
int * gerarConjuntoCasoMedio(int n);